using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChasePlayer : MonoBehaviour
{
    public Transform target; // the specific sprite to be chased
    public float speed = 4f; // how fast the chaser is
    // Start is called before the first frame update
    // Update is called once per frame
    private void Update()
    {
        if(target != null){
        float distance = Vector2.Distance(transform.position, target.position);
        Vector2 direction = (target.position - transform.position).normalized;
        // calculate direction of target
        transform.position += (Vector3)direction * speed * Time.deltaTime;
        // move chaser towards target
        }
    }
}