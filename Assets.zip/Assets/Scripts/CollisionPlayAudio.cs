using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class CollisionPlayAudio : MonoBehaviour
{
    // Start is called before the first frame update
    
    public AudioSource yourAudio;
    // creates audio input variable
      void Start()
    {
        yourAudio = GetComponent<AudioSource>();
        if (yourAudio == null){
            Debug.LogError("AudioSource component is missing from this GameObject.");
             }
    }
    void OnTriggerEnter2D(Collider2D col){
        if (col.CompareTag("Player")){
            yourAudio.Play();
        }
    }
}
