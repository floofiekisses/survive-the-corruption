using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour

{
     public float movSpeed;
        float speedX, speedY;
        // movement speed
        Rigidbody2D rb;
        // creates rigidbody variable
    // Start is called before the first frame update
    void Start()
    {
       rb = GetComponent<Rigidbody2D>();
       // connect rb with the rigidbody of the thing
        
    }

    // Update is called once per frame
    void Update()
    {
        speedX = Input.GetAxisRaw("Horizontal") * movSpeed;
        // speed x is equal to the key you're pressing times the movement speed
        speedY = Input.GetAxisRaw("Vertical") * movSpeed;
        // speed y is equal to the key you're pressing times the movement speed
        rb.velocity = new Vector2(speedX, speedY);
    }
}